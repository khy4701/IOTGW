package com.kt.restful.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.kt.restful.model.UserInfo;

@Path("/getUserInfo")
public class UserService {

	private static Logger logger = LogManager.getLogger(UserService.class);
	private static final String GET_SUBS_INFO_QRY = "SELECT * FROM TBL_USER_INFO";
	
	@GET
	@Path("{mdn}")
	@Produces("application/json;charset=UTF-8")
	public Response getUserInfo(@HeaderParam("akey") String akey, @HeaderParam("channel") String channel, @PathParam("mdn") String mdn) {
		
		System.out.println("mdn : " + mdn );
		Statement stmt = null;
		ResultSet rs = null;
		JSONObject responseJSONObject = new JSONObject();
		JSONObject data = new JSONObject();
		String result = "";
		
		logger.info("[getUserInfo] input MDN : " + mdn);
		
		if (mdn == null || mdn.equals("")) 
		{
			responseJSONObject.put("resultCode", "REP10007");
			responseJSONObject.put("resultMessage", "mdn ������ Ȯ���� �ּ���.");
			responseJSONObject.put("data", data);
			
			result = responseJSONObject.toString();
			
			logger.info("[getUserInfo] Result");
			logger.info(result);
			
			return Response.status(200).entity(responseJSONObject.toString()).header("akey", "pl@sm#897&82160").header("channel", "plism").build();
		}
		
		if(!akey.equals("pl@sm#897&82160")) {
			responseJSONObject.put("resultCode", "REP99999");
			responseJSONObject.put("resultMessage", "system error");
			responseJSONObject.put("data", data);
			
			result = responseJSONObject.toString();
			
			logger.info("[getUserInfo] Result");
			logger.info(result);
			
			return Response.status(200).entity(responseJSONObject.toString()).header("akey", "pl@sm#897&82160").header("channel", "plism").build();
		}
		
		if(!channel.equals("plism")) {
			responseJSONObject.put("resultCode", "REP99999");
			responseJSONObject.put("resultMessage", "system error");
			responseJSONObject.put("data", data);
			
			result = responseJSONObject.toString();
			
			logger.info("[getUserInfo] Result");
			logger.info(result);
			
			return Response.status(200).entity(responseJSONObject.toString()).header("akey", "pl@sm#897&82160").header("channel", "plism").build();
		}
		
		
		try {
			stmt = DBConnector.getInstance().getConnect().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			rs = stmt.executeQuery(GET_SUBS_INFO_QRY + " WHERE MDN = '"+ mdn +"'");
			logger.debug(GET_SUBS_INFO_QRY + " WHERE MDN = '"+ mdn +"'");
			
			while(rs.next()){
				for (UserInfo userInfo : UserInfo.values()) {
					data.put(userInfo.getName(), rs.getString(userInfo.toString()));
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		} finally {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				logger.error(e.getMessage());
			} finally {
				rs = null;
				stmt = null;
			}
		}
		
		responseJSONObject.put("resultCode", "REP00000");
		responseJSONObject.put("resultMessage", "����ó�� �Ǿ����ϴ�");
		responseJSONObject.put("data", data);
		
		result = responseJSONObject.toString();
		
		logger.info("[getUserInfo] Result");
		logger.info(result);
		
		return Response.status(200).entity(result).header("akey", "pl@sm#897&82160").header("channel", "plism").build();
	}
}
